Simple NFC reader for Android based on the sample code from the Android SDK.

<a href="https://f-droid.org/repository/browse/?fdid=se.anyro.nfc_reader" target="_blank">
<img src="https://f-droid.org/badge/get-it-on.png" alt="Get it on F-Droid" height="90"/></a>
<a href="https://play.google.com/store/apps/details?id=se.anyro.nfc_reader" target="_blank">
<img src="https://play.google.com/intl/en_us/badges/images/generic/en-play-badge.png" alt="Get it on Google Play" height="90"/></a>

If you have problem compiling the app make sure you have the /libs/guavalib.jar included in the build path.
