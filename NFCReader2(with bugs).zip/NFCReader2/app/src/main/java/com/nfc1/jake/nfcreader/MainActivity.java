package com.nfc1.jake.nfcreader;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.format.Time;
import android.view.View;


public class MainActivity extends AppCompatActivity {

        Time mTime;
        Handler Handler;
        Runnable r;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTime = new Time();

        r = new Runnable() {
            @Override
            public void run() {

                mTime.setToNow();
                drawingView dv = new drawingView(MainActivity.this,
                        mTime.hour, mTime.minute, mTime.second, mTime.weekDay,mTime.monthDay, getBatteryLevel());

                setContentView(dv);
                Handler.postDelayed(r , 1000);

            }
        };

        Handler = new Handler();
        Handler.postDelayed(r,1000);
        }
        public float getBatteryLevel(){
        Intent BatteryIntent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int level = BatteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = BatteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

            if(level==-1 || scale==-1){
                return 50.50f;

            }
                return ((float) level   /   (float) scale) *100.0f;
    }

        public class drawingView extends View {

        Paint mBackgroundPaint, mTextPaint, mTextPaintBack;

        Typeface tf;

        int hours, minutes, secounds, weekday, datee;
        float battery;

            public drawingView(Context context, int hours, int minutes, int secounds, int weekday, int datee, float battery) {
                super(context);

                tf = Typeface.createFromAsset(getAssets(),"font.ttf");

                mBackgroundPaint = new Paint();
                mBackgroundPaint.setColor(ContextCompat.getColor(getApplicationContext(),R.color.background));

                mTextPaint = new Paint();
                mTextPaint.setColor(ContextCompat.getColor(getApplicationContext(),R.color.text));
                mTextPaint.setAntiAlias(true);
                mTextPaint.setTextAlign(Paint.Align.CENTER);
                mTextPaint.setTextSize(getResources().getDimension(R.dimen.text_size));
                mTextPaint.setTypeface(tf);

                mTextPaintBack = new Paint();
                mTextPaintBack.setColor(ContextCompat.getColor(getApplicationContext(),R.color.text_back));
                mTextPaintBack.setAntiAlias(true);
                mTextPaintBack.setTextAlign(Paint.Align.CENTER);
                mTextPaintBack.setTextSize(getResources().getDimension(R.dimen.text_size));
                mTextPaintBack.setTypeface(tf);

                this.hours = hours;
                this.minutes = minutes;
                this.secounds = secounds;
                this.weekday = weekday;
                this.datee = datee;
                this.battery = battery;


            }

            @Override
            protected void onDraw(Canvas canvas) {
                super.onDraw(canvas);

                float width = canvas.getWidth();
                float height = canvas.getHeight();

                canvas.drawRect(0,0, width, height, mBackgroundPaint);

                float centreX = width / 2f;
                float centreY = height / 2f;

                int cur_hour = hours;
                String cur_ampm = "AM";
                if(cur_hour == 0){
                    cur_hour = 12;
                }
                if(cur_hour > 12){
                    cur_hour = cur_hour - 12;
                    cur_ampm = "PM";
                }

                String text = String.format("%02d:%02d:%02d", cur_hour,minutes,secounds);

                String day_of_week = "";

                if(weekday == 1){
                    day_of_week = "MON";
                }
                else if(weekday == 2){
                    day_of_week = "TUE";
                }
                else if(weekday == 3){
                    day_of_week = "WED";
                }
                else if(weekday == 4){
                    day_of_week = "THURS";
                }
                else if(weekday == 5){
                    day_of_week = "FRI";
                }
                else if(weekday == 6){
                    day_of_week = "SAT";
                }
                else if(weekday == 7){
                    day_of_week = "SUN";
                }

                String text2 = String.format("DATE:%s %d", day_of_week, datee);

                String batteryLevel = "BATTERY" + (int)battery + "%";

                canvas.drawText("00 00 00 ", centreX , centreY, mTextPaintBack);

                mTextPaint.setColor(ContextCompat.getColor(getApplicationContext(),R.color.text));
                mTextPaint.setTextSize(getResources().getDimension(R.dimen.text_size));
                canvas.drawText(text, centreX, centreY, mTextPaint);

                mTextPaint.setColor(ContextCompat.getColor(getApplicationContext(),R.color.text));
                mTextPaint.setTextSize(getResources().getDimension(R.dimen.text_size_small));
                canvas.drawText(batteryLevel + "" + text2,
                        centreX,
                        centreY + getResources().getDimension(R.dimen.text_size_small),
                        mTextPaint);




            }
        }

}
