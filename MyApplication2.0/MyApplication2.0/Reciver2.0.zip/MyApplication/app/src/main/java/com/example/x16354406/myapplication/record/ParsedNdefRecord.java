package com.example.x16354406.myapplication.record;

/**
 * Created by x16354406 on 13/04/2018.
 */

public interface ParsedNdefRecord {
    String str();

}
