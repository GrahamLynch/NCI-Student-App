package com.example.x16354406.nfcreader;

import android.net.Uri;

/**
 * Created by x16354406 on 13/04/2018.
 */

public class UriRecord {
    public UriRecord(Uri uri) {
    }
}
